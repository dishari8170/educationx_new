import grpDB from "@/models/grpDB"
export default async function handler(req, res) {

    if (res.method==="POST") {

        const user = await grpDB.create({name:req.body.name})


        res.status(200).json(user);

    }else {


        const user = await grpDB.find({})

        res.status(200).json(user);

    }


}