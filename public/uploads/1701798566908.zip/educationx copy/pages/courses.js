import CoursesC from "@/components/CoursesC";
import HeadderX from "@/components/headerx";
import Futter from "@/components/futter";
import Homebnr from "@/components/homebnr";

export default function Courses() {
    return <>

        <HeadderX/>

        <CoursesC/>
        <Homebnr/>
        <Futter/>

        </>
}