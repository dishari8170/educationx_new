import HeadderX from "@/components/headerx";
import AboutUs from "@/components/AboutUs";
import Futter from "@/components/futter";
import StoreX from "@/components/StoreX";

export default function Store() {
    return  <><HeadderX/>
        <StoreX/>
        <Futter/>
    </>
}