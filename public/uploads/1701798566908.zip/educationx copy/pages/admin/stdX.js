export default ()=>{


    return <>
        <div className="d-flex justify-content-center  container text-center" style={{backgroundColor:"lightslategrey"}}>



            <div className="d-flex">

                <select>
                    {

                    }
                </select>


            </div>

        </div>


    </>
}