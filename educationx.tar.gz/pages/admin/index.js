import STDash from "@/components/STDash";
import AdminDash from "@/components/AdminDash";
import Futter from "@/components/futter";
import HeadderX from "@/components/headerx";

export default ()=>{


    return          <>

        <HeadderX/>

     <div className="d-flex" >

        <AdminDash/>
        <div className="w-100 h-100 bg-black">dhhhfhfjhhj</div>

    </div> </>
}